
-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `firstname`, `lastname`, `email`, `gender`, `password`, `contact`) VALUES
(1, 'yaman', 'danish', 'yaman@gmail.com', 'male', '1d8178cfec37daec7c6386797316917f', '8896111950'),
(2, 'Ayush', 'Mishra', '28ayush02mishra@gmail.com', 'male', 'c1aedd14ac31030e4a9b72cd40ed4b1c', '6388289145'),
(3, 'Sukant', 'Arora', 'sukant@gmail.com', 'male', 'ef77e3290433d1f345e49b9db03e3871', '7398868892');
